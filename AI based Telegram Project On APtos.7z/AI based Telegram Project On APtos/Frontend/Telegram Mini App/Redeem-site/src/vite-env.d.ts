/// <reference types="vite/client" />

interface Window {
  Telegram: any; // Replace 'any' with a more specific type if available
}
